var jpdbBaseURL = "http://api.login2explore.com:5577" ;
var jpdbIRL = "/api/irl";
var jpdbIML = "/api/iml";
var shipDBName = "DELIVERY-DB";
shipRealtionName = "Ship-Rel";
var connToken = "90932915|-31949280322027296|90947610";

$("#shipno").focus();

function saveRecNo1LS(jsonObj) {
    var lvData = JSON>parseFloat(jsonObj.data);
    localStorage.setItem("recno",lvData.rec_no);
}
function getShipNoAsJsonObj() {
    var shipno = $("#shipno").val();
    var jsonStr = {
        id: shipno
    };
    return JSON.stringify(jsonStr);
}

function fillDate(jsonObj) {
    saveRecNo1LS(jsonObj);
    var record = JSON.parse(jsonObj.data).record;
    $("#description").val(data.description);
    $("#source").val(data.source);
    $("#des").val(data.des);
    $("#shipdate").val(data.shipdate);
    $("#expdate").val(data.expdate);
}

function resetForm() {
    $("#shipno").val("");
    $("#description").val("");
    $("#source").val("");
    $("#des").val("");
    $("#shipdate").val("");
    $("#expdate").val(""); 
    $("#shipno").prop("disabled",false);
    $("#save").prop("disabled",true);
    $("#change").prop("disabled",true);
    $("#reset").prop("disabled",true);
    $("#shipno").focus();  
}

function validateDate() {
    var shipno,description,source,des,shipdate,expdate;
    shipno = $("#shipno").val();
    description = $("#description").val();
    source = $("#source").val();
    des = $("#des").val();
    shipdate = $("#shipdate").val();
    expdate = $("#expdate").val();

    if(shipno === "") {
        alert("Shipping number is missing");
        $("#shipno").focus();
        return "";
    }
    if(description === "") {
        alert("Description is missing");
        $("#description").focus();
        return "";
    }
    if(source === "") {
        alert("SOurce  is missing");
        $("#source").focus();
        return "";
    }
    if(des === "") {
        alert("Destination number is missing");
        $("#des").focus();
        return "";
    }
    if(shipdate === "") {
        alert("Shipping Date is missing");
        $("#shipdate").focus();
        return "";
    }
    if(expdate === "") {
        alert("Expected Delivery Date is missing");
        $("#shipno").focus();
        return "";
    }

    var jsonStrObj = {
        shipno: shipno,
        description: description,
        source: source,
        des: des,
        shipdate: shipdate,
        expdate: expdate
    };
    return JSON.stringify(jsonStrObj);
}

function getShip() {
    var getShipNoJsonObj = getShipNoAsJsonObj();
    var getRequest = createGET_BY_KEYRequest(connToken, shipDBName, shipRealtionName, getShipNoJsonObj);
    jQuery.ajaxSetup({async: false});
    var resJsonObj = executeCommandAtGivenBaseUrl(getRequest, jpdbBaseURL, jpdbIRL);
    jQuery.ajaxSetup({async: true});
    if(resJsonObj.status===400) {
        $("#save").prop("disabled",false);
        $("#reset").prop("disabled",false);
        $("#description").focus();

    } else if (resJsonObj.status === 200) {
        $("#shipno").prop("disabled",true);
        fillDate(resJsonObj);

        $("#change").prop("disabled",false);
        $("#reset").prop("disabled",false);
        $("#description").focus();
    }
}

function saveData() {
    var jsonObj = validateDate();
    if(jsonStrObj === " ") {
        return "";
    }
    var putRequest = createPUTRequest(connToken, jsonObj, shipDBName, shipRealtionName);
    jQuery.ajaxSetup({async:false});
    var resJsonObj = executeCommandAtGivenBaseUrl(putRequest, jpdbBaseURL, jpdbIML);
    jQuery.ajaxSetup({async:true});
    resetForm();
    $("#shipno").focus();
}

function changeData() {
    $("#change").prop("disabled", true);
    jsonChg = validateDate();
    var updateRequest = createUPDATERecordRequest(connToken, jsonChg, shipDBName, shipRealtionName, localStorage.getItem("recno"));
    jQuery.ajaxSetup({async: false});
    var resJsonObj = executeCommandAtGivenBaseUrl(updateRequest, jpdbBaseURL, jpdbIML);
    jQuery.ajaxSetup({async: true});
    console.log(resJsonObj);
    $("#shipno").focus();
}
